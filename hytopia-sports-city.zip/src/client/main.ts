// PSEUDOCODE: client bootstrap.

import { setupNetworkBridge } from "./network";
import { Hud } from "./ui/hud";
import { InputController } from "./controllers/input-controller";
import "./ui/hud.css";

async function main() {
  const client = await (window as any).createHytopiaClient({
    containerId: "game-root"
  });

  setupNetworkBridge(client);

  new Hud(client, "hud-root");
  new InputController(client);

  console.log("Pregame City client initialized.");
}

main().catch(console.error);
