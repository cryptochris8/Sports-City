// PSEUDOCODE: Bridge raw server messages to client event system.

type ClientLike = {
  connection: {
    onMessage(cb: (msg: any) => void): void;
  };
  emit(eventName: string, data?: any): void;
};

export function setupNetworkBridge(client: ClientLike) {
  client.connection.onMessage(msg => {
    switch (msg.type) {
      case "zoneChanged":
        client.emit("zoneChanged", msg);
        break;
      case "challengeStarted":
        client.emit("challengeStarted", msg);
        break;
      case "challengeScoreUpdated":
        client.emit("challengeScoreUpdated", msg);
        break;
      case "challengeEnded":
        client.emit("challengeEnded", msg);
        break;
      case "xpUpdated":
        client.emit("xpUpdated", msg);
        break;
      case "coinsUpdated":
        client.emit("coinsUpdated", msg);
        break;
      case "notification":
        client.emit("notification", msg);
        break;
      default:
        break;
    }
  });
}
