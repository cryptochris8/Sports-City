// PSEUDOCODE: handles E/G/C input and nearby field context.

type NearbyFieldContext = {
  fieldId: string;
  sport: string;
};

export class InputController {
  private nearbyField: NearbyFieldContext | null = null;

  constructor(private client: any) {
    this.registerKeybinds();
    this.registerFieldEvents();
  }

  private registerKeybinds() {
    window.addEventListener("keydown", e => {
      if (e.key === "e" || e.key === "E") {
        if (this.nearbyField) {
          this.startChallengeForField(this.nearbyField);
        }
      }

      if (e.key === "g" || e.key === "G") {
        console.log("Open emote wheel (stub)");
      }

      if (e.key === "c" || e.key === "C") {
        console.log("Open quick chat (stub)");
      }
    });
  }

  private registerFieldEvents() {
    this.client.on("enteredSportsFieldTrigger", (data: any) => {
      this.nearbyField = {
        fieldId: data.fieldId,
        sport: data.sport
      };
    });

    this.client.on("exitedSportsFieldTrigger", () => {
      this.nearbyField = null;
    });
  }

  private startChallengeForField(field: NearbyFieldContext) {
    this.client.connection.send({
      type: "uiRequestStartChallenge",
      sport: field.sport,
      challengeId: this.getDefaultChallengeId(field.sport),
      fieldId: field.fieldId
    });
  }

  private getDefaultChallengeId(sport: string): string {
    switch (sport) {
      case "basketball":
        return "basketball_shooting_60s";
      default:
        return "basketball_shooting_60s";
    }
  }
}
