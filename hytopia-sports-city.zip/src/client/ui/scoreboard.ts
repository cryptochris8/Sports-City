export class Scoreboard {
  // Placeholder for future scoreboard implementation.
  constructor(private client: any, rootElId: string = "scoreboard-root") {}
}
