# Pregame City – Hytopia Multiplayer Sports World (Challenge-First)

This project is a starter kit for a Hytopia sports world where players explore a city
and play **solo shooting/skill challenges** for basketball, football, soccer, baseball, and tennis.

It is intentionally:
- **Server-authoritative**
- **Config-driven** (zones, challenges, spawns)
- Friendly to **Claude Code / MCP / Cursor** workflows.

Most code is **pseudocode TypeScript** and must be wired to the real Hytopia SDK APIs.
