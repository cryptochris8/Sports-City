import fs from "node:fs";
import path from "node:path";

type Vec3 = { x: number; y: number; z: number };

type SportsField = {
  id: string;
  sport: string;
  mode: string;
  center: Vec3;
  maxPlayers: number;
};

type ZoneConfig = {
  id: string;
  type: string;
  center: Vec3;
  radius: number;
  spawnPoint?: Vec3;
  sportsFields?: SportsField[];
};

type ZonesFile = {
  version: number;
  zones: ZoneConfig[];
};

function generateBuildInstructions(zonesConfig: ZonesFile) {
  const instructions: any[] = [];
  for (const zone of zonesConfig.zones) {
    if (zone.type === "hub") {
      instructions.push({
        kind: "hub_zone",
        zoneId: zone.id,
        center: zone.center,
        radius: zone.radius,
        features: ["plaza_ground", "spawn_pad"]
      });
    } else if (zone.type.startsWith("district_sport_")) {
      instructions.push({
        kind: "sports_district",
        zoneId: zone.id,
        center: zone.center,
        radius: zone.radius,
        fields: (zone.sportsFields ?? []).map(f => ({
          fieldId: f.id,
          sport: f.sport,
          center: f.center
        }))
      });
    }
  }
  return instructions;
}

function main() {
  const zonesPath = path.join(__dirname, "..", "config", "zones.json");
  const outDir = path.join(__dirname, "out");
  const outPath = path.join(outDir, "map_build_instructions.json");

  const raw = fs.readFileSync(zonesPath, "utf-8");
  const zonesConfig = JSON.parse(raw) as ZonesFile;

  const instructions = generateBuildInstructions(zonesConfig);

  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(outPath, JSON.stringify({ version: 1, instructions }, null, 2));

  console.log("Map build instructions written to:", outPath);
}

main();
